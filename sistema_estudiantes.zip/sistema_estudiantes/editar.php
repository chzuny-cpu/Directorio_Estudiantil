<?php
require_once 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id      = $_POST['id'];
    $dni     = trim($_POST['dni']);
    $nombres = trim($_POST['nombres']);
    $celular = trim($_POST['celular']);
    $correo  = trim($_POST['correo']);

    // Comprobar si se subió una nueva foto
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $fotoName = uniqid() . '_' . $dni . '.' . $ext;
        $destino = 'uploads/' . $fotoName;

        if (move_uploaded_file($_FILES['foto']['tmp_name'], $destino)) {
            // Eliminar foto antigua si no es la por defecto
            $stmtFoto = $pdo->prepare("SELECT foto FROM estudiantes WHERE id = ?");
            $stmtFoto->execute([$id]);
            $antigua = $stmtFoto->fetch();
            if ($antigua && file_exists('uploads/' . $antigua['foto'])) {
                unlink('uploads/' . $antigua['foto']);
            }

            // Actualizar datos con foto
            $stmt = $pdo->prepare("UPDATE estudiantes SET dni = ?, nombres = ?, celular = ?, correo = ?, foto = ? WHERE id = ?");
            $stmt->execute([$dni, $nombres, $celular, $correo, $fotoName, $id]);
            header('Location: index.php');
            exit;
        }
    }

    // Actualizar datos sin cambiar foto
    $stmt = $pdo->prepare("UPDATE estudiantes SET dni = ?, nombres = ?, celular = ?, correo = ? WHERE id = ?");
    $stmt->execute([$dni, $nombres, $celular, $correo, $id]);

    header('Location: index.php');
    exit;
}
?>
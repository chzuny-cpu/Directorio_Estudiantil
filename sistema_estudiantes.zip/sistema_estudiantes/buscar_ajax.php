<?php
require_once 'conexion.php';

$q = $_GET['q'] ?? '';

if (trim($q) === '') {
    echo '';
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM estudiantes 
                       WHERE dni LIKE :q OR nombres LIKE :q OR correo LIKE :q OR celular LIKE :q 
                       LIMIT 5");
$stmt->execute(['q' => "%$q%"]);
$resultados = $stmt->fetchAll();

if (count($resultados) > 0) {
    foreach ($resultados as $row) {
        $fotoPath = !empty($row['foto']) && file_exists('uploads/' . $row['foto']) 
                    ? 'uploads/' . $row['foto'] 
                    : 'https://via.placeholder.com/150';

        echo "<div class='p-2 border-bottom d-flex align-items-center'>
                <img src='{$fotoPath}' class='rounded-circle me-3' width='35' height='35' style='object-fit:cover;'>
                <div>
                    <strong>{$row['nombres']}</strong> <small class='text-primary'>(DNI: {$row['dni']})</small><br>
                    <small class='text-muted'>{$row['correo']} | {$row['celular']}</small>
                </div>
              </div>";
    }
} else {
    echo "<div class='p-2 text-muted text-center'>Sin coincidencias (Máx. 5).</div>";
}
?>
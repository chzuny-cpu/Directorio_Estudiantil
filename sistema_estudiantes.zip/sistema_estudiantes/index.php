<?php
require_once 'conexion.php';

// Paginación dinámica (10, 20, 50, 100)
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

// Total de registros
$total_stmt = $pdo->query("SELECT COUNT(*) FROM estudiantes");
$total_rows = $total_stmt->fetchColumn();
$total_pages = ceil($total_rows / $limit);

// Consulta paginada
$stmt = $pdo->prepare("SELECT * FROM estudiantes ORDER BY id DESC LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$estudiantes = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Estudiantes • Portal Digital</title>
    <!-- Bootstrap 5 CSS e Iconos -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Librería para generar Código QR en JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <style>
        :root {
            --lila-principal: #c084fc;
            --lila-claro: #f3e8ff;
            --lila-oscuro: #9333ea;
            --celeste-principal: #38bdf8;
            --celeste-claro: #e0f2fe;
            --texto-oscuro: #1e1b4b;
            --texto-suave: #4c1d95;
            --gradiente-aesthetic: linear-gradient(135deg, #c084fc 0%, #38bdf8 100%);
        }

        body {
            background: linear-gradient(180deg, #f5f3ff 0%, #e0f2fe 50%, #f0f9ff 100%);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--texto-oscuro);
            min-height: 100vh;
        }

        .main-card {
            background: #ffffff;
            border-radius: 24px !important;
            border: 1.5px solid rgba(192, 132, 252, 0.3) !important;
            box-shadow: 0 20px 40px -15px rgba(192, 132, 252, 0.2) !important;
            overflow: hidden;
        }

        .header-banner {
            background: var(--gradiente-aesthetic) !important;
            border-radius: 24px 24px 0 0;
            padding: 28px 32px;
        }

        .badge-sub {
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(8px);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.5px;
            display: inline-block;
            margin-bottom: 8px;
            border: 1px solid rgba(255, 255, 255, 0.4);
        }

        .foto-thumb {
            width: 48px;
            height: 48px;
            object-fit: cover;
            border-radius: 50%;
            cursor: pointer;
            border: 2px solid var(--lila-principal);
            padding: 2px;
            background: #ffffff;
            box-shadow: 0 4px 10px rgba(192, 132, 252, 0.25);
            transition: transform 0.2s ease-in-out;
        }
        .foto-thumb:hover { transform: scale(1.15); }

        .btn-aesthetic {
            background: var(--gradiente-aesthetic);
            color: #ffffff !important;
            border: none;
            border-radius: 14px;
            font-weight: 700;
            box-shadow: 0 4px 12px rgba(192, 132, 252, 0.3);
            transition: all 0.2s ease;
        }
        .btn-aesthetic:hover {
            opacity: 0.92;
            transform: translateY(-1px);
        }

        .btn-aesthetic-light {
            background: #ffffff;
            color: var(--texto-suave) !important;
            border: none;
            border-radius: 14px;
            font-weight: 700;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
            transition: all 0.2s ease;
        }
        .btn-aesthetic-light:hover {
            transform: translateY(-1px);
            background: var(--lila-claro);
        }

        .badge-dni {
            background-color: var(--celeste-claro);
            color: #0284c7;
            border-radius: 10px;
            padding: 5px 12px;
            font-weight: 700;
        }

        .table-light-custom th {
            background-color: #f8fafc;
            color: var(--texto-suave);
            font-weight: 800;
            font-size: 12px;
            letter-spacing: 0.8px;
            border-bottom: 1px solid #f1f5f9;
        }

        /* MODALES CON ESTILO LILA / CELESTE */
        .modal-content {
            border-radius: 26px !important;
            border: 1.5px solid var(--lila-principal) !important;
            box-shadow: 0 25px 50px -12px rgba(192, 132, 252, 0.35) !important;
            overflow: hidden;
        }

        .modal-header-aesthetic {
            background: var(--gradiente-aesthetic) !important;
            color: white;
            padding: 20px 24px;
            border: none;
        }

        .form-control, .form-select {
            border-radius: 14px;
            border: 1.5px solid #e2e8f0;
            padding: 10px 16px;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--lila-principal);
            box-shadow: 0 0 0 4px rgba(192, 132, 252, 0.15);
        }

        .pagination .page-link {
            border-radius: 10px;
            margin: 0 3px;
            color: var(--texto-suave);
            border: 1px solid rgba(192, 132, 252, 0.3);
        }

        .pagination .page-item.active .page-link {
            background: var(--gradiente-aesthetic);
            border: none;
            color: white;
        }
    </style>
</head>
<body>

<div class="container my-4">
    <div class="card main-card">
        <!-- Encabezado Banner Lila / Celeste -->
        <div class="header-banner text-white d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
                <span class="badge-sub">✦ IESTP • PORTAL ESTUDIANTIL ✦</span>
                <h3 class="fw-bold mb-1"><i class="bi bi-mortarboard-fill me-2"></i>Gestión de Estudiantes</h3>
                <p class="mb-0 opacity-90 small">Administra, busca y visualiza los carnets digitales.</p>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-aesthetic-light px-3 py-2" data-bs-toggle="modal" data-bs-target="#modalBuscar">
                    <i class="bi bi-search me-1"></i> Buscar
                </button>
                <button class="btn btn-aesthetic px-3 py-2" data-bs-toggle="modal" data-bs-target="#modalNuevo">
                    <i class="bi bi-person-plus-fill me-1"></i> Nuevo
                </button>
            </div>
        </div>

        <div class="card-body p-4">
            <!-- Barra Superior: Total y Paginación -->
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                <span class="badge px-3 py-2" style="background: var(--lila-claro); color: var(--texto-suave); font-size: 13px; border-radius: 12px; border: 1px solid rgba(192,132,252,0.3);">
                    Total: <strong class="text-dark"><?= $total_rows ?></strong> estudiantes
                </span>
                
                <form method="GET" class="d-flex align-items-center">
                    <label class="me-2 text-muted small fw-bold">Mostrar:</label>
                    <select name="limit" class="form-select form-select-sm w-auto" onchange="this.form.submit()">
                        <option value="10" <?= $limit == 10 ? 'selected' : '' ?>>10</option>
                        <option value="20" <?= $limit == 20 ? 'selected' : '' ?>>20</option>
                        <option value="50" <?= $limit == 50 ? 'selected' : '' ?>>50</option>
                        <option value="100" <?= $limit == 100 ? 'selected' : '' ?>>100</option>
                    </select>
                </form>
            </div>

            <!-- Tabla de Datos -->
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light-custom">
                        <tr>
                            <th>FOTO</th>
                            <th>DNI</th>
                            <th>NOMBRES</th>
                            <th>CONTACTO</th>
                            <th class="text-center">ACCIONES</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($estudiantes) > 0): ?>
                            <?php foreach ($estudiantes as $est): ?>
                            <tr>
                                <td>
                                    <?php 
                                        $fotoPath = !empty($est['foto']) && file_exists('uploads/' . $est['foto']) 
                                                    ? 'uploads/' . $est['foto'] 
                                                    : 'uploads/default.jpg';
                                    ?>
                                    <img src="<?= $fotoPath ?>" class="foto-thumb" onclick="ampliarFoto('<?= $fotoPath ?>')" alt="Foto" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($est['nombres']) ?>&background=c084fc&color=fff';">
                                </td>
                                <td><span class="badge-dni"><?= htmlspecialchars($est['dni']) ?></span></td>
                                <td class="fw-bold" style="color: var(--texto-oscuro);"><?= htmlspecialchars($est['nombres']) ?></td>
                                <td>
                                    <div class="small text-muted"><i class="bi bi-telephone me-1" style="color: var(--lila-principal);"></i><?= htmlspecialchars($est['celular']) ?></div>
                                    <div class="small text-muted"><i class="bi bi-envelope me-1" style="color: var(--lila-principal);"></i><?= htmlspecialchars($est['correo']) ?></div>
                                </td>
                                <td class="text-center">
                                    <!-- Botón Ver QR -->
                                    <button class="btn btn-sm me-1" style="background: var(--celeste-claro); color: #0284c7; border-radius: 10px; border: 1px solid rgba(56, 189, 248, 0.4);" title="Ver QR" onclick="generarQR('<?= $est['dni'] ?>', '<?= htmlspecialchars(addslashes($est['nombres'])) ?>')">
                                        <i class="bi bi-qr-code"></i>
                                    </button>
                                    <!-- Botón Editar -->
                                    <button class="btn btn-sm me-1" style="background: #fef9c3; color: #ca8a04; border-radius: 10px; border: 1px solid #fde047;" title="Editar" onclick='abrirModalEditar(<?= json_encode($est) ?>)'>
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <!-- Botón Eliminar -->
                                    <a href="eliminar.php?id=<?= $est['id'] ?>" class="btn btn-sm" style="background: #ffe4e6; color: #e11d48; border-radius: 10px; border: 1px solid #fecdd3;" title="Eliminar" onclick="return confirm('¿Seguro de eliminar este estudiante? 💜')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">No hay estudiantes registrados.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginación -->
            <?php if ($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination pagination-sm justify-content-center">
                    <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="?page=<?= $page - 1 ?>&limit=<?= $limit ?>">Anterior</a>
                    </li>
                    <?php for($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= $page == $i ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>&limit=<?= $limit ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                        <a class="page-link" href="?page=<?= $page + 1 ?>&limit=<?= $limit ?>">Siguiente</a>
                    </li>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- MODAL 1: Crear Nuevo Estudiante -->
<div class="modal fade" id="modalNuevo" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form action="guardar.php" method="POST" enctype="multipart/form-data" class="modal-content">
            <div class="modal-header modal-header-aesthetic">
                <h5 class="modal-title fw-bold"><i class="bi bi-person-plus me-2"></i>Nuevo Estudiante</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="form-label fw-bold">DNI</label>
                    <input type="text" name="dni" class="form-control" required maxlength="15" placeholder="Escriba DNI...">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Nombres Completos</label>
                    <input type="text" name="nombres" class="form-control" required placeholder="Nombres y Apellidos...">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Celular</label>
                    <input type="text" name="celular" class="form-control" required placeholder="Número telefónico...">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Correo Electrónico</label>
                    <input type="email" name="correo" class="form-control" required placeholder="correo@ejemplo.com">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Foto de Perfil</label>
                    <input type="file" name="foto" class="form-control" accept="image/*">
                </div>
            </div>
            <div class="modal-footer border-0 p-4 pt-0">
                <button type="button" class="btn btn-light rounded-3 fw-bold" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-aesthetic px-4 py-2">Guardar Estudiante 💜</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 2: Editar Estudiante -->
<div class="modal fade" id="modalEditar" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form action="editar.php" method="POST" enctype="multipart/form-data" class="modal-content">
            <div class="modal-header modal-header-aesthetic">
                <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2"></i>Editar Estudiante</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <input type="hidden" name="id" id="edit_id">
                <div class="mb-3">
                    <label class="form-label fw-bold">DNI</label>
                    <input type="text" name="dni" id="edit_dni" class="form-control" required maxlength="15">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Nombres Completos</label>
                    <input type="text" name="nombres" id="edit_nombres" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Celular</label>
                    <input type="text" name="celular" id="edit_celular" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Correo Electrónico</label>
                    <input type="email" name="correo" id="edit_correo" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Cambiar Foto (Opcional)</label>
                    <input type="file" name="foto" class="form-control" accept="image/*">
                </div>
            </div>
            <div class="modal-footer border-0 p-4 pt-0">
                <button type="button" class="btn btn-light rounded-3 fw-bold" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-aesthetic px-4 py-2">Actualizar Cambios 🩵</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 3: Código QR -->
<div class="modal fade" id="modalQR" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered text-center">
        <div class="modal-content">
            <div class="modal-header modal-header-aesthetic">
                <h5 class="modal-title fw-bold w-100"><i class="bi bi-qr-code me-2"></i>Código QR del Estudiante</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body d-flex flex-column align-items-center p-4">
                <h6 id="qrNombreEstudiante" class="fw-bold mb-3" style="color: var(--texto-oscuro);"></h6>
                <div id="qrcode" class="p-3 border-0 rounded-4 shadow-sm" style="background: var(--lila-claro);"></div>
                <small class="text-muted mt-3">Contenido del QR: <strong id="qrDniValue" style="color: var(--lila-oscuro);"></strong></small>
                <button type="button" class="btn btn-aesthetic mt-4 px-4 py-2" data-bs-dismiss="modal">Cerrar 💜</button>
            </div>
        </div>
    </div>
</div>

<!-- MODAL 4: Búsqueda Flotante AJAX (Máximo 5 registros) -->
<div class="modal fade" id="modalBuscar" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header modal-header-aesthetic">
                <h5 class="modal-title fw-bold"><i class="bi bi-search me-2"></i>Búsqueda Flotante (Máx. 5)</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <input type="text" id="inputBuscar" class="form-control" placeholder="Escriba DNI, Nombre o Correo..." onkeyup="buscarLive()">
                <div id="resultadosLive" class="mt-3"></div>
            </div>
        </div>
    </div>
</div>

<!-- MODAL 5: Ampliar Foto -->
<div class="modal fade" id="modalFoto" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered text-center">
        <div class="modal-content bg-transparent border-0 shadow-none">
            <div class="modal-body p-0">
                <img id="imgAmpliada" src="" class="img-fluid rounded-4 shadow-lg" style="max-height: 80vh; border: 3px solid var(--lila-principal);">
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// 1. Ampliar Foto al hacer clic
function ampliarFoto(src) {
    document.getElementById('imgAmpliada').src = src;
    new bootstrap.Modal(document.getElementById('modalFoto')).show();
}

// 2. Generar Código QR dinámico
function generarQR(dni, nombres) {
    document.getElementById('qrNombreEstudiante').innerText = nombres;
    document.getElementById('qrDniValue').innerText = dni;
    
    let qrContainer = document.getElementById('qrcode');
    qrContainer.innerHTML = ""; // Limpiar QR anterior
    
    new QRCode(qrContainer, {
        text: dni,
        width: 180,
        height: 180,
        colorDark : "#1e1b4b",
        colorLight : "#f3e8ff",
        correctLevel : QRCode.CorrectLevel.H
    });

    new bootstrap.Modal(document.getElementById('modalQR')).show();
}

// 3. Cargar Datos en Modal Editar
function abrirModalEditar(estudiante) {
    document.getElementById('edit_id').value = estudiante.id;
    document.getElementById('edit_dni').value = estudiante.dni;
    document.getElementById('edit_nombres').value = estudiante.nombres;
    document.getElementById('edit_celular').value = estudiante.celular;
    document.getElementById('edit_correo').value = estudiante.correo;

    new bootstrap.Modal(document.getElementById('modalEditar')).show();
}

// 4. Búsqueda Flotante AJAX
function buscarLive() {
    let q = document.getElementById('inputBuscar').value;
    if (q.trim().length === 0) {
        document.getElementById('resultadosLive').innerHTML = '';
        return;
    }
    fetch('buscar_ajax.php?q=' + encodeURIComponent(q))
        .then(res => res.text())
        .then(html => {
            document.getElementById('resultadosLive').innerHTML = html;
        });
}
</script>
</body>
</html>
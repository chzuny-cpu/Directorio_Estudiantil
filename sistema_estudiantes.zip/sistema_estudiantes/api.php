<?php
header('Content-Type: application/json; charset=utf-8');
error_reporting(0);

require_once 'conexion.php';

$dni = isset($_GET['dni']) ? trim($_GET['dni']) : '';

if (empty($dni)) {
    echo json_encode(["status" => "error", "message" => "DNI no proporcionado"]);
    exit;
}

if (!isset($pdo)) {
    echo json_encode(["status" => "error", "message" => "Error en la conexión a la base de datos"]);
    exit;
}

try {
    // Consulta utilizando la conexión $pdo
    $stmt = $pdo->prepare("SELECT * FROM estudiantes WHERE dni = :dni");
    $stmt->execute([':dni' => $dni]);
    $row = $stmt->fetch();

    if ($row) {
        echo json_encode([
            "status" => "success",
            "data" => [
                "dni"     => $row['dni'],
                "nombres" => $row['nombres'],
                "celular" => $row['celular'],
                "correo"  => $row['correo'],
                "foto"    => $row['foto']
            ]
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Estudiante no encontrado"]);
    }
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "Error en la base de datos: " . $e->getMessage()]);
}
?>
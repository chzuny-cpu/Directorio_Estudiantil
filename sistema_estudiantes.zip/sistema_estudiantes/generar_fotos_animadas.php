<?php
set_time_limit(300);
ini_set('display_errors', 1);
error_reporting(E_ALL);

$dir = __DIR__ . '/uploads/';
if (!file_exists($dir)) {
    mkdir($dir, 0777, true);
}

echo "<h2 style='font-family:sans-serif; color:#7c3aed;'>✨ Descargando 50 fotos de estudiantes jóvenes, bien presentados y bonitos...</h2>";

// Selección curada de IDs de fotos bonitas, limpias y de alta calidad
// Retratos femeninos jóvenes y amables
$fotos_mujeres = [1, 2, 3, 5, 8, 10, 12, 14, 16, 18, 20, 21, 23, 26, 27, 28, 31, 32, 35, 38, 40, 44, 45, 48, 49];

// Retratos masculinos jóvenes, arreglados y formales
$fotos_varones = [1, 3, 4, 7, 8, 11, 12, 14, 15, 18, 22, 24, 25, 29, 32, 33, 36, 42, 45, 46, 51, 52, 54, 58, 60];

for ($i = 1; $i <= 50; $i++) {
    $filename = "foto{$i}.jpg";
    $filePath = $dir . $filename;

    // Impares: Mujeres (Ivanna, Paloma, Milagros)
    // Pares: Varones (Maximiliano, Ignacio, Tomás)
    $esChica = ($i % 2 != 0);
    $posicion = floor(($i - 1) / 2) % 25;

    if ($esChica) {
        $id = $fotos_mujeres[$posicion];
        $url = "https://randomuser.me/api/portraits/women/{$id}.jpg";
    } else {
        $id = $fotos_varones[$posicion];
        $url = "https://randomuser.me/api/portraits/men/{$id}.jpg";
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    $imgData = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($imgData && $httpCode == 200 && strlen($imgData) > 500) {
        file_put_contents($filePath, $imgData);
        $generoTexto = $esChica ? "Chica 🌸" : "Chico 👔";
        echo "<div style='font-family:sans-serif; color:#059669; margin-bottom:3px;'>✨ <b>{$filename}</b> ({$generoTexto}) - Retrato guardado correctamente</div>";
    } else {
        echo "<div style='font-family:sans-serif; color:#dc2626;'>❌ Error al guardar {$filename}</div>";
    }

    if (ob_get_level() > 0) ob_flush();
    flush();
}

echo "<br><h3 style='font-family:sans-serif; color:#7c3aed;'>🎉 ¡Listo! Se actualizaron las 50 fotos con retratos selectos en /uploads/.</h3>";
?>
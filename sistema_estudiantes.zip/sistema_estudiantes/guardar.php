<?php
require_once 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dni     = trim($_POST['dni']);
    $nombres = trim($_POST['nombres']);
    $celular = trim($_POST['celular']);
    $correo  = trim($_POST['correo']);
    $fotoName = "";

    // Comprobar si se subió una foto
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $fotoName = uniqid() . '_' . $dni . '.' . $ext;
        $destino = 'uploads/' . $fotoName;

        // Asegurarse de que la carpeta uploads exista
        if (!file_exists('uploads')) {
            mkdir('uploads', 0777, true);
        }

        move_uploaded_file($_FILES['foto']['tmp_name'], $destino);
    }

    try {
        // Insertar en la base de datos
        $stmt = $pdo->prepare("INSERT INTO estudiantes (dni, nombres, celular, correo, foto) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$dni, $nombres, $celular, $correo, $fotoName]);
        
        // Redirigir de vuelta al panel principal
        header('Location: index.php');
        exit;
    } catch (Exception $e) {
        die("Error al guardar el estudiante: " . $e->getMessage());
    }
}
?>